Dear Reader,

Contained in this directory are some recently unearthed documents which
sketch a design for a programming language called "Befunge", which,
it should be noted, bears little resemblance to the programming language
now known as Befunge.

These documents are dated January 1993, whereas the Befunge-93 documents
are dated September 1993.  This seems to indicate that the name "Befunge"
was in existence for at least eight months before it settled on the
programming language that was to become attached to it.

I make no apologies for the rhetorical excesses found in these documents,
nor for the cockamamie approach to language design that they embody.

Chris Pressey  
London (THE London)  
June 6, 2018
